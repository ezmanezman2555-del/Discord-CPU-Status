﻿import asyncio
import aiohttp
import json
import sys
import os
import psutil
from colorama import Fore, Style, init

init(autoreset=True)

ASCII_ART = r"""
   _____      _                 _   _                      
  / ____|    | |               | \ | |                     
 | |    _   _| |__   ___ _ __  |  \| |_   ___   _______  __
 | |   | | | | '_ \ / _ \ '__| | . ` | | | \ \ / / _ \ \/ /
 | |___| |_| | |_) |  __/ |    | |\  | |_| |\ V /  __/>  < 
  \_____\__, |_.__/ \___|_|    |_| \_|\__,_| \_/ \___/_/\_\
         __/ |                                             
        |___/                                                                       
"""

def gradient_text(text):
    colors = [Fore.RED, Fore.YELLOW, Fore.GREEN, Fore.CYAN, Fore.BLUE, Fore.MAGENTA]
    gradient_text = ""
    for i, char in enumerate(text):
        if char != "\n":
            gradient_text += colors[i % len(colors)] + char
        else:
            gradient_text += char
    return gradient_text

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def center_text(text):
    lines = text.strip("\n").split("\n")
    terminal_width = os.get_terminal_size().columns
    centered_lines = [
        line.center(terminal_width) for line in lines
    ]
    return "\n".join(centered_lines)

def get_ram_usage():
    memory = psutil.virtual_memory()
    return memory.percent

def get_cpu_utilization():
    return psutil.cpu_percent(interval=1)

async def update_status_loop(token: str):
    """อัปเดตสถานะผ่าน HTTP API เท่านั้น"""
    headers = {
        "Authorization": token,
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0"
    }
    
    session = None
    
    try:
        session = aiohttp.ClientSession()
        
        while True:
            try:
                cpu_usage = get_cpu_utilization()
                ram_usage = get_ram_usage()
                status_message = f"CPU: {cpu_usage:.1f}% | RAM: {ram_usage:.1f}%"
                
                payload = {
                    "custom_status": {"text": status_message}
                }
                
                async with session.patch(
                    "https://discord.com/api/v9/users/@me/settings",
                    headers=headers,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    if response.status == 200:
                        print(f"Status updated: {status_message}")
                    elif response.status == 401:
                        print("Error: Invalid token")
                        break
                    else:
                        print(f"HTTP Error: {response.status}")
                
                await asyncio.sleep(5)
                
            except Exception as e:
                print(f"Error updating status: {e}")
                await asyncio.sleep(10)
                
    finally:
        if session:
            await session.close()

async def main():
    try:
        with open("config.json", "r") as config_file:
            config = json.load(config_file)
            TOKEN = config["TOKEN"]
    except FileNotFoundError:
        print("Error: config.json not found!")
        print("Please create config.json with your Discord token")
        sys.exit(1)
    clear_screen()
    print(gradient_text(center_text(ASCII_ART)))
    
    try:
        print("Starting status updater (HTTP API only)...")
        await update_status_loop(TOKEN)
    except KeyboardInterrupt:
        print("\nShutting down...")
    except Exception as e:
        print(f"Fatal error: {e}")

if __name__ == "__main__":
    asyncio.run(main())